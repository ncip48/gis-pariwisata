</div>
</div>
</section>
<!-- END WELCOME-->

<!-- COPYRIGHT-->
<section class="p-t-60 p-b-20">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="copyright">
					<p>Pariwisata Kebumen</p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- END COPYRIGHT-->
</div>

</div>



<!-- Vendor JS       -->
<script src="<?= base_url() ?>template/vendor/slick/slick.min.js">
</script>
<script src="<?= base_url() ?>template/vendor/wow/wow.min.js"></script>
<script src="<?= base_url() ?>template/vendor/animsition/animsition.min.js"></script>
<script src="<?= base_url() ?>template/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
</script>
<script src="<?= base_url() ?>template/vendor/counter-up/jquery.waypoints.min.js"></script>
<script src="<?= base_url() ?>template/vendor/counter-up/jquery.counterup.min.js">
</script>
<script src="<?= base_url() ?>template/vendor/circle-progress/circle-progress.min.js"></script>
<script src="<?= base_url() ?>template/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="<?= base_url() ?>template/vendor/chartjs/Chart.bundle.min.js"></script>
<script src="<?= base_url() ?>template/vendor/select2/select2.min.js">
</script>

<!-- Main JS-->
<script src="<?= base_url() ?>template/js/main.js"></script>

</body>

</html>